# Multimodel-AI-Agent-For-Investment-Risk-Assessment
Investment risk assessment describe the process of identifying, evaluating, and quantifying the risks that could affect an investment’s performance.Itfocuses specifically on risks inherent in an investment (such as market, credit, or liquidity risks).In this Multimodel AI Agent we have use four agents like Data Analyst, Trading Strategy Developer, Trade Advisor, and Risk Advisor to monitor market data, develop trading strategies, plan executions, and assess risks  accurately.

Techstack:
[1]CREWAI
[2]Python3
